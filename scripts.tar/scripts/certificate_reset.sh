#!/bin/bash

set +x
cd ~
echo `pwd`
rm switch*.pem
rm /etc/openvswitch/nsx-controller-cacert**
ovs-pki -f init
ovs-pki req+sign switch switch
mv switch*.pem /etc/openvswitch

